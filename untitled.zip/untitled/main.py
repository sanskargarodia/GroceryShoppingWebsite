from flask import Flask, render_template, request, redirect, url_for,flash
#from flask_sqlalchemy import SQLAlchemy
from flask_mysqldb import MySQL
import yaml






app = Flask(__name__)

db = yaml.load(open("templates/db.yaml"))
app.config['MYSQL_HOST'] = db['mysql_host']
app.config['MYSQL_USER'] = db['mysql_user']
app.config['MYSQL_PASSWORD'] = db['mysql_password']
app.config['MYSQL_DB'] = db['mysql_db']

#app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@127.0.0.1:3360/dbms_miniproject'
#db = SQLAlchemy(app)

mysql = MySQL(app)


@app.route("/", methods=['GET', 'POST'])
def hello():
    if request.method == 'POST':
        logindetails = request.form
        Cust_Id = logindetails['Cust_Id']
        Cust_Password = logindetails['Cust_Password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM dbms_miniproject.customer WHERE Cust_Id = %s AND Cust_Password = %s", [Cust_Id, Cust_Password])
        mysql.connection.commit()
        resultValue = cur.fetchall()
        for i in resultValue:
            if(i[0]):
                return redirect(url_for('miniproject'))
            else:
                flash("VAlid eafdf")

    return render_template('login.html')




@app.route("/miniproject")
def miniproject():
    return render_template('miniproject.html')



@app.route("/map")
def map():
    return render_template('map.html')



@app.route("/signup", methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        userdetails = request.form
        Cust_Id = userdetails['Cust_Id']
        Cust_Password = userdetails['Cust_Password']
        Cust_Name = userdetails['Cust_Name']
        Cust_Email = userdetails['Cust_Email']
        Cust_Phone_No = userdetails['Cust_Phone_No']
        Cust_Address = userdetails['Cust_Address']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO dbms_miniproject.customer values(%s,%s,%s,%s,%s,%s)", (Cust_Id, Cust_Name, Cust_Email, Cust_Phone_No, Cust_Address, Cust_Password))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('miniproject'))

    return render_template("signup.html")





@app.route("/Fruits", methods=['GET', 'POST'])
def Fruits():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s OR product_type=%s ", ['Fruits', 'Vegetables'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("fruits.html", data=data)



@app.route("/Dairy", methods=['GET', 'POST'])
def Dairy():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s", ['Dairy'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("dairy.html", data=data)



@app.route("/PersonalCare", methods=['GET', 'POST'])
def PersonalCare():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s", ['Personal Care'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("personalcare.html", data=data)



@app.route("/Vegetables", methods=['GET', 'POST'])
def Vegetables():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s OR product_type=%s ", ['Fruits', 'Vegetables'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("fruits.html", data=data)



@app.route("/search", methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        searchdetails = request.form
        Search = searchdetails['Search']
        cur = mysql.connection.cursor()
        cur.execute("SELECT product_type FROM dbms_miniproject.product where product_name like %s", [Search])
        mysql.connection.commit()
        data = cur.fetchall()
        if len(data) != 0:
            for i in data:
                None;
            return redirect(url_for(i[0]))
    return render_template("miniproject.html")

@app.route("/cart", methods=['GET','POST'])
def cart():
    if request.method == 'POST':
        additem = request.form.get
        product_name = additem('product_name')
        image = additem('image')
        price = additem('price')
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO dbms_miniproject.cart(product_id, qty) VALUES(%s,1)", ["SELECT product_id FROM dbms_miniproject.product WHERE product_name=%s", [product_name]])
        mysql.connection.commit()
        cur.close()
    return render_template("cart.html")




@app.route("/Homecare", methods=['GET', 'POST'])
def homecare():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s OR product_type=%s ", ['Homecare'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("Homecare.html", data=data)



if __name__ == '__main__' :
    app.run(debug=True)
