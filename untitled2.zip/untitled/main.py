from flask import Flask, render_template, request, redirect, url_for,flash
#from flask_sqlalchemy import SQLAlchemy
from flask_mysqldb import MySQL
import yaml






app = Flask(__name__)

db = yaml.load(open("templates/db.yaml"))
app.config['MYSQL_HOST'] = db['mysql_host']
app.config['MYSQL_USER'] = db['mysql_user']
app.config['MYSQL_PASSWORD'] = db['mysql_password']
app.config['MYSQL_DB'] = db['mysql_db']

#app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:@127.0.0.1:3360/dbms_miniproject'
#db = SQLAlchemy(app)

mysql = MySQL(app)
Cust_Id = ''
@app.route("/", methods=['GET', 'POST'])
def hello():
    if request.method == 'POST':
        logindetails = request.form
        Cust_Id = logindetails['Cust_Id']
        Cust_Password = logindetails['Cust_Password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM dbms_miniproject.customer WHERE Cust_Id = %s AND Cust_Password = %s", [Cust_Id, Cust_Password])
        mysql.connection.commit()
        resultValue = cur.fetchall()
        for i in resultValue:
            if(i[0]):
                return redirect(url_for('miniproject'))
            else:
                flash("VAlid eafdf")

    return render_template('login.html')

@app.route("/login_manager", methods=['GET','POST'])
def login():
    if request.method == 'POST':
        logindetails = request.form
        Manager_Id = logindetails['empid']
        Manager_Password = logindetails['Emp_Password']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM dbms_miniproject.employee WHERE empid = %s AND Emp_Password = %s", [Manager_Id, Manager_Password])
        mysql.connection.commit()
        resultValue = cur.fetchall()
        for i in resultValue:
            if (i[0]):
                return redirect(url_for('manager'))
    return render_template("login_manager.html")


@app.route("/manager", methods=['GET', 'POST'])
def manager():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.stock")
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("manager.html", data=data)



@app.route("/signup_manager", methods=['GET', 'POST'])
def signup_manager():
    if request.method == 'POST':
        userdetails = request.form
        empid = userdetails['empid']
        ename = userdetails['ename']
        etype = userdetails['etype']
        ephone = userdetails['ephone']
        eaddress = userdetails['eaddress']
        salary = userdetails['salary']
        estore = userdetails['estore']
        Emp_Password = userdetails['Emp_Password']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO dbms_miniproject.employee values(%s,%s,%s,%s,%s,%s)", (empid, ename, etype, ephone, eaddress, salary, estore, Emp_Password))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('miniproject'))

    return render_template("signup_manager.html")




@app.route("/miniproject")
def miniproject():
    return render_template('miniproject.html')







@app.route("/signup", methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        userdetails = request.form
        Cust_Id = userdetails['Cust_Id']
        Cust_Password = userdetails['Cust_Password']
        Cust_Name = userdetails['Cust_Name']
        Cust_Email = userdetails['Cust_Email']
        Cust_Phone_No = userdetails['Cust_Phone_No']
        Cust_Address = userdetails['Cust_Address']
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO dbms_miniproject.customer values(%s,%s,%s,%s,%s,%s)", (Cust_Id, Cust_Name, Cust_Email, Cust_Phone_No, Cust_Address, Cust_Password))
        mysql.connection.commit()
        cur.close()
        return redirect(url_for('miniproject'))

    return render_template("signup.html")





@app.route("/Fruits", methods=['GET', 'POST'])
def Fruits():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s OR product_type=%s ", ['Fruits', 'Vegetables'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("fruits.html", data=data)



@app.route("/Dairy", methods=['GET', 'POST'])
def Dairy():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s", ['Dairy'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("dairy.html", data=data)



@app.route("/PersonalCare", methods=['GET', 'POST'])
def PersonalCare():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s", ['Personal Care'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("personalcare.html", data=data)



@app.route("/Vegetables", methods=['GET', 'POST'])
def Vegetables():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s OR product_type=%s ", ['Fruits', 'Vegetables'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("fruits.html", data=data)



@app.route("/search", methods=['GET', 'POST'])
def search():
    if request.method == 'POST':
        searchdetails = request.form
        Search = searchdetails['Search']
        cur = mysql.connection.cursor()
        cur.execute("SELECT product_name,price,product_type FROM dbms_miniproject.product where product_name like %s or product_type like %s", [Search,Search])
        mysql.connection.commit()
        data = cur.fetchall()
        for i in data:
            None;
        if len(data) != 0:
            cur.execute("SELECT product_name,price,product_type FROM dbms_miniproject.product WHERE product_type = %s", [i[2]])
            mysql.connection.commit()
            data1 = cur.fetchall()
        else:
            cur.execute("SELECT product_name,price,product_type FROM dbms_miniproject.product")
            mysql.connection.commit()
            data1 = cur.fetchall()
            data=['empty']
    return render_template("search.html", data=data, data1=data1)



@app.route("/cart", methods=['GET','POST'])
def cart():
    if request.method == 'POST':
        additem = request.form
        product_name = additem['product_name']
        price = additem['price']
        cur = mysql.connection.cursor()
        cur.execute("SELECT product_id FROM dbms_miniproject.product WHERE product_name = %s", [product_name])
        mysql.connection.commit()
        product_id = cur.fetchall()
        cur.execute("INSERT INTO dbms_miniproject.cart(Cust_Id, product_id, qty) VALUES(%s,%s,1)", [Cust_Id, product_id])
        mysql.connection.commit()
        cur.execute("SELECT * FROM dbms_miniproject.cart where Cust_Id =%s", [Cust_Id])
        mysql.connection.commit()
        data = cur.fetchall()
        cur.execute("SELECT * FROM dbms_miniproject.product")
        mysql.connection.commit()
        data1 = cur.fetchall()
        return render_template("cart.html", data=data, data1=data1)
    return render_template("cart.html")



@app.route("/add", methods=['GET','POST'])
def add():
    if request.method == 'POST':
        add=request.form
        addtocart = add['Quantity']
        product_id = add['product_id']
        cur = mysql.connection.cursor()
        cur.execute("UPDATE cart SET qty=%s WHERE product_id=%s", [addtocart, product_id])
        mysql.connection.commit()
        cur.execute("SELECT qty FROM dbms_miniproject.cart")
        mysql.connection.commit()
        data2 = cur.fetchall()
        return render_template("cart.html", data2=data2)
    return render_template("cart.html")




@app.route("/manager_order", methods=['GET','POST'])
def manager_order():
    cur = mysql.connection.cursor()
    cur.execute("SELECT count(product_id) FROM dbms_miniproject.product")
    mysql.connection.commit()
    product = cur.fetchall()
    for i in range (product):
        tobeorder = request.form['product[i]']
        cur.execute("INSERT INTO d")
        mysql.connection.commit()
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product")
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("manager_order.html", data=data)

@app.route("/ordered", methods=['GET','POST'])
def ordered():
    if request.method=='POST':
        add=request.form

@app.route("/map", methods=['GET','POST'])
def map():
    return render_template("map.html")



@app.route("/HomeCare", methods=['GET', 'POST'])
def HomeCare():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s", ['Home Care'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("HomeCare.html", data=data)



@app.route("/Trader", methods=['GET', 'POST'])
def Trader():
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM dbms_miniproject.product WHERE product_type=%s", ['Home Care'])
    mysql.connection.commit()
    data = cur.fetchall()
    return render_template("trader.html", data=data)



if __name__ == '__main__' :
    app.run(debug=True)
